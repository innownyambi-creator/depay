/**
 * LEGEND CUT LCB — EmailJS Configuration
 * =========================================
 * Developed by Nhabinde I.
 *
 * HOW TO SET UP EMAIL NOTIFICATIONS FOR BOOKINGS
 * ------------------------------------------------
 * When a customer fills in the booking form, you will receive
 * an email with all their booking details.
 *
 * STEP 1: Create a free EmailJS account
 * ──────────────────────────────────────
 * Go to: https://www.emailjs.com
 * Sign up with your Gmail or email address.
 * Free plan gives you 200 emails/month — more than enough.
 *
 * STEP 2: Connect your Email Service
 * ────────────────────────────────────
 * - Click "Email Services" in the sidebar
 * - Click "Add New Service"
 * - Choose Gmail (or any provider)
 * - Name it "LegendCutLCB"
 * - Copy the SERVICE ID (looks like "service_xxxxxxx")
 * - Update EMAILJS_CONFIG.serviceId in js/main.js
 *
 * STEP 3: Create an Email Template
 * ──────────────────────────────────
 * - Click "Email Templates" in the sidebar
 * - Click "Create New Template"
 * - Set the Subject to:
 *     New Booking: {{service}} — {{from_name}}
 * - Paste this in the Body:
 *
 * ─────────────────────────────────
 * New booking received at Legend Cut LCB!
 *
 * Customer Name:  {{from_name}}
 * Phone Number:   {{from_phone}}
 * Service:        {{service}}
 * Price:          {{price}}
 * Preferred Date: {{date}}
 * Preferred Time: {{time}}
 *
 * Additional Notes:
 * {{message}}
 *
 * To reply, call the customer at: {{from_phone}}
 * ─────────────────────────────────
 *
 * - Copy the TEMPLATE ID (looks like "template_xxxxxxx")
 * - Update EMAILJS_CONFIG.templateId in js/main.js
 *
 * STEP 4: Get your Public Key
 * ────────────────────────────
 * - Click your account name (top right) → "Account"
 * - Under "API Keys", copy the PUBLIC KEY
 * - Update EMAILJS_CONFIG.publicKey in js/main.js
 *
 * STEP 5: Update your receiving email
 * ─────────────────────────────────────
 * - Update EMAILJS_CONFIG.toEmail to your actual email address
 * - This is where booking notifications will be sent
 *
 * TESTING
 * ────────
 * - Open the website
 * - Fill in the booking form and submit
 * - Check your inbox for the booking notification
 * - Check the browser console for any errors
 *
 * TROUBLESHOOTING
 * ───────────────
 * - "EmailJS not configured" in console → You haven't updated the IDs yet
 * - Emails going to spam → Add emailjs.com to your safe senders
 * - 401 error → Wrong Public Key
 * - 400 error → Wrong Service or Template ID
 *
 * OPTIONAL: Google Sheets Integration
 * ─────────────────────────────────────
 * If you want bookings saved to a spreadsheet as well:
 * 1. Create a Google Sheet
 * 2. Go to Extensions → Apps Script
 * 3. Paste the doPost() function from the README
 * 4. Deploy as Web App → copy the URL
 * 5. Update SHEETS_CONFIG.webhookUrl in this file
 */

// ══════════════════════════════════════════
//  OPTIONAL: Google Sheets Webhook Config
//  (uncomment and fill in if you want to
//   also save bookings to a spreadsheet)
// ══════════════════════════════════════════
/*
const SHEETS_CONFIG = {
  webhookUrl: 'YOUR_APPS_SCRIPT_WEB_APP_URL'
};

async function saveToSheets(data) {
  try {
    await fetch(SHEETS_CONFIG.webhookUrl, {
      method: 'POST',
      mode: 'no-cors',
      body: JSON.stringify(data),
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    console.warn('Sheets save failed (non-critical):', err);
  }
}
*/
